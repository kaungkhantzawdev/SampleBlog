    </div>


</div>
</section>

<script src="<?php echo $url;?>/assets/vendor/jquery-3.3.1.min.js"></script>
<script src="<?php echo $url;?>/assets/vendor/popper.js"></script>
<script src="<?php echo $url;?>/assets/vendor/bootstrap_5/js/bootstrap.bundle.js"></script>
<script src="<?php echo $url;?>/assets/vendor/way_point/jquery.waypoints.js"></script>
<script src="<?php echo $url;?>/assets/vendor/counter_up/counter_up.js"></script>
<script src="<?php echo $url;?>/assets/vendor/chart_js/chart.min.js"></script>

<script src="<?php echo $url;?>/assets/js/app.js"></script>
<script src="<?php echo $url;?>/assets/js/dashboard.js"></script>
</body>
</html>